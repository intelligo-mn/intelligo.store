<?php

return [
    'approved' => 'Сайн уу :UserName, Бидэнд маш их мэдээ байна!<br>
                   Таны <b>:PostTitle</b> мэдээг зөвшөөрлөө. Та нэвтэрч холбоосыг нь хуваалцаж болно:<br> <b>:Postlink</b>',

    'approvedsubject' => 'Таны мэдээг зөвшөөрлөө!',

    'trashed' => 'Сайн уу :UserName, Бид муу мэдээтэй!<br>
                  Таны <b>:PostTitle</b> мэдээ устлаа. :(',

    'trashsubject' => 'Таны мэдээг устгалаа!',
];
