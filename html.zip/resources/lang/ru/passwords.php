<?php

return array (
  'password' => 'Пароли должны быть не менее шести символов.',
  'reset' => 'Ваш пароль успешно сброшен!',
  'sent' => 'Мы отправили Вам ссылку для сброса пароля!',
  'token' => 'Данная ссылка больше не действительна',
  'user' => 'Мы не можем найти пользователя с таким E-mail.',
  'passwordreslink' => 'Отправить',
  'yourpasswordreslink' => 'Ваша ссылка для сброса пароля',
  'forgotpassword' => 'Забыли Пароль? ',
  'resetpass' => 'Сбросить Пароль',
  'passemail' => 'Email',
  'passpassword' => 'Пароль',
  'passpasswordconf' => 'Пароль еще раз',
);
