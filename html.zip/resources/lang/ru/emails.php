<?php

return [
    'approved' => 'Привет, :UserName!<br>
                   Твой пост <b>:PostTitle</b> опубликован. Теперь можешь поделиться ссылкой в социальных сетях url:<br> <b>:Postlink</b>',

    'approvedsubject' => 'Ваш пост одобрен!',

    'trashed' => 'Привет :UserName, У Нас плохие новости!<br>
                  Твой пост <b>:PostTitle</b> был удален. попытайтесь написать что-нибудь еще :(',

    'trashsubject' => 'Ваш пост удален!',
];
