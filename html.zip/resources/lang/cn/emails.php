<?php

return [
    'approved' => 'Hi :UserName, We have great news!<br>
                   Your Post <b>:PostTitle</b> has been approved. You can access and share with this url:<br> <b>:Postlink</b>',

    'approvedsubject' => 'Your post has been approved!',

    'trashed' => 'Hi :UserName, We have bad news!<br>
                  Your Post <b>:PostTitle</b> has been deleted. :(',

    'trashsubject' => 'Your post has been deleted!',
];
