<?php

return array (
  'yourpasswordreslink' => 'Uw wachtwoord Reset Link',
  'sent' => 'Wij hebben uw wachtwoord reset link aan u verzonden!',
  'user' => 'Wij kunnen geen gebruiker vinden met dit email adres.',
  'resetpass' => 'Reset wachtwoord',
  'passemail' => 'Email',
  'passwordreslink' => 'Stuur Reset Link',
  'forgotpassword' => 'Wachtwoord vergeten? ',
  'passpassword' => 'Wachtwoord',
  'passpasswordconf' => 'Bevestig wachtwoord',
  'password' => 'Wachtwoord moet minstens 6 tekens bevatten en gelijk zijn aan de bevestiging.',
  'reset' => 'Uw wachtwoord hebben wij opnieuw ingesteld!',
  'token' => 'Dit wachtwoord reset verzoek is ongeldig.',
);
