<div class="modeempty-header">
    <div class="modeempty_text">

        <i class="fa fa-info-circle"></i>
        <h4>{{ trans('index.emptyplace') }}</h4>
    </div>

</div>