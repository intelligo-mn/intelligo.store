<?php

return [
    'approved' => 'Ciao :UserName, Abbiamo una grande notizia!<br>
                   il tuo Post <b>:PostTitle</b> è stato approvato. puoi accedere e condividerlo con questo url:<br> <b>:Postlink</b>',

    'approvedsubject' => 'Il tuo post è stato approvato!',

    'trashed' => 'Ciao :UserName, Abbiamo una brutta notizia!<br>
                  Il tuo Post <b>:PostTitle</b> è stato cancellato. :(',

    'trashsubject' => 'Il tuo post è stato cancellato!',
];
