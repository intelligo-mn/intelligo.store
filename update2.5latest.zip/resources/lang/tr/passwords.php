<?php

return array (
  'password' => 'Şifre enaz 6 karakter olmalı ve uyuşmalıdır',
  'reset' => 'Şifreniz değiştirildi!',
  'sent' => 'Şifre sıfırlama adresini mail ile gönderdik!',
  'token' => 'Şifre değiştirmeniz geçersidir.',
  'user' => 'Bu mail adresinde bir kayıt bulamadık',
  'passwordreslink' => 'Sıfırla adresi gönder',
  'yourpasswordreslink' => 'Senin sıfırlama adresin',
  'forgotpassword' => 'Şifreni mi unuttun? ',
  'resetpass' => 'Şifre sıfırla',
  'passemail' => 'Email',
  'passpassword' => 'Şifre',
  'passpasswordconf' => 'Şifre onayla',
);
