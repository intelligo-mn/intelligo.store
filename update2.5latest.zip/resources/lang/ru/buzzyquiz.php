<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Buzzy Quiz Plugin Lines
    |--------------------------------------------------------------------------
    */

    //General
    'quiz'              => 'Quiz',

    'quizzes'           => 'Quizzes',

    'question'          => 'Question',

    'questions'         => 'Questions',

    'entry_question'    => 'Question Title (Opsiyonel)',

    'answer'             => 'Answer',

    'entry_answertitle'  => 'Answer Text',

    'quizresults'        => 'Quiz Results',

    'result'             => 'Result',

    'add'                => 'Result',


     'yougot'            => 'You got: :title',



    'answererrors'       => 'Entry #:numberofentry - Answer #:numberofanswer  Error: :error',
];
