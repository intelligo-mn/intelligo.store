# dgl-api

## Холбоосууд

    Админ = "http://www.dgl.toroo.info/";
    Ангилал авах = "http://www.dgl.toroo.info/api/get-category.php";
    Ангилалд хамаатай бүтээгдэхүүнүүд = "http://www.dgl.toroo.info/api/get-product-category-id.php";
    Бүх бүтээгдэхүүн = "http://www.dgl.toroo.info/api/get-all-product.php";
    Бүтээгдэхүүн = "http://www.dgl.toroo.info/api/get-product.php";
    Захиалга илгээх = "http://www.dgl.toroo.info/api/add-order.php";
    Бүх байгууллагын мэдээлэл = "http://www.dgl.toroo.info/api/get-company.php";

