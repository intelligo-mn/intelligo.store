<?php
	include($_SERVER['DOCUMENT_ROOT'].'/config/variables.php');
	$connect->close();
?>