<?php include('config/variables.php'); ?>
<div id="footer">
</div>