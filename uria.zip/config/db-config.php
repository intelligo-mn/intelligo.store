<?php

return array(
    'table' => 'settings'
);